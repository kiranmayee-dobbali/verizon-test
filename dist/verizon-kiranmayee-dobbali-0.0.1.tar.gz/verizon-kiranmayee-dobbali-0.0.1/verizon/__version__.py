__title__ = 'verizon'
__description__ = 'This is for verizon test'
__version__ = '0.0.1'